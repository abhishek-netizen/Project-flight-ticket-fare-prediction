import sqlite3

con = sqlite3.connect("fare.db")
cur = con.cursor()

cur.execute('''CREATE TABLE flights(
ID INTEGER PRIMARY KEY AUTOINCREMENT,
DATE DATE,
DOMESTIC TEXT,
INTERNATIONAL TEXT
);''')

print('table created')

con.commit()
cur.close()
con.close()
